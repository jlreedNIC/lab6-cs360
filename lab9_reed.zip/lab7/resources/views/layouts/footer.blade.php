<div class="row">
    <div class="col-lg-12">
        <div class="footer">
            <p>2022 © 513 Studios.</p>
        </div>
    </div>
</div>