<div class="container-fluid" style="background-color:white">
    <div class="row">
        <div class="col-lg-12">
            <div class="float-right">
                
                <div class="dropdown dib">
                    <div class="header-icon" data-toggle="dropdown">
                        <a href="{{ route('logout') }}">
                            <i class="ti-power-off"></i>
                            <span>Logout</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>