<div class="row">
    <div class="col-md-6">
        <div class="page-header">
            <div class="page-title">
                <h1>Hello and Welcome!</h1>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="page-header">
            <div class="page-title">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                    <li class="breadcrumb-item active">Home</li>
                </ol>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\lab-cs360\lab7-cs360\lab7\resources\views/layouts/header.blade.php ENDPATH**/ ?>