<html>
   <head>
      <title>DemoLaravel - <?php echo $__env->yieldContent('title'); ?></title>
   </head>
   <body>
      <?php echo $__env->yieldContent('content'); ?>
   </body>
</html><?php /**PATH C:\xampp\htdocs\lab-cs360\lab7-cs360\lab7\resources\views/master.blade.php ENDPATH**/ ?>