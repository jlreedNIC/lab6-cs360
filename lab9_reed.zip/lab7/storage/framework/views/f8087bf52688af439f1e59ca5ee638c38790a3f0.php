<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://use.fontawesome.com/e8f26e73ec.js"></script>
    </head>
    <body>
        <div class="navbar">
            <button class="btn" style="padding:5px">
                <a href="logout.php">Logout</a>
            </button>
        </div>
        <div class="container-fluid">
            <h1 style="text-align:center; padding:30px">Hey, <?php //echo $_SESSION['username']; ?>!</h1>
            <!-- <p>You are now on the user dashboard page.</p> -->
        </div>

        <?php
        //require('db.php'); // connect to database
        // query database for all users
        //$query    = "SELECT * 
        //             FROM `users`";
        //$result = mysqli_query($con, $query) or die(mysql_error());
        ?>
    
        <div class="container-fluid">
            <h2>User Table</h2>
            <form>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">User Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Password</th>
                        <th scope="col"> </th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    //while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
                    // {
                    //     echo "<tr>". 
                    //     "<td>{$row['username']}</td>". 
                    //     "<td>{$row['email']}</td>".
                    //     "<td>{$row['password']}</td>".
                    //     "<td> ".
                    //         "<button class='btn' value='".$row['id']."'> <span class='fa fa-minus-circle' style='color:rgb(202, 0, 0)'></span> </button>".
                    //     "</td>".
                    // "</tr>";
                    // }

                    ?>
                </tbody>
            </table>
            </form>
        </div>
    
        <div class="container-fluid">
            
    
            <?php
                // require('db.php');
                // When form submitted, insert values into the database.
                // if (isset($_REQUEST['username'])) {
                //     // removes backslashes
                //     $username = stripslashes($_REQUEST['username']);
                //     //escapes special characters in a string
                //     $username = mysqli_real_escape_string($con, $username);
                //     $email    = stripslashes($_REQUEST['email']);
                //     $email    = mysqli_real_escape_string($con, $email);
                //     $password = stripslashes($_REQUEST['password']);
                //     $password = mysqli_real_escape_string($con, $password);
                //     $create_datetime = date("Y-m-d H:i:s");
                //     $query    = "INSERT into `users` (username, password, email, create_datetime)
                //                 VALUES ('$username', '" . md5($password) . "', '$email', '$create_datetime')";
                //     $result   = mysqli_query($con, $query);
                //     if ($result) {
                //         echo "<div class='container'>
                //             <h3 style='text-align: center; padding: 50px'>User registered successfully. Reload the page to see an updated table</h3><br/>
                            
                //             </div>";
                //         $_REQUEST['username'] = null;
                //         echo "here: ".$_REQUEST['username']."<br>";
                //         echo isset($_REQUEST['username']);
                //         header("Refresh: 0");
                //         document.getElementByID("registerform").reset();
                //     } else {
                //         echo "<div class='container' style='text-align: center'>
                //             <h3 style='text-align: center'>Required fields are missing.</h3><br/>
                //             <p class='link' style='text-align: center'>Click here to <a href='registration.php'>registration</a> again.</p>
                //             </div>";
                //     }
                // } else {
            ?>
            <form class="container-fluid col-md-5" action="" method="post" id="registerform">
                <h1 class="container" style="text-align:center; padding: 20px">Register A New User</h1>
            
                <div class="form-group row">
                    <!-- <div class="col-md-3">
                        <label class="form-label text-muted">Username:</label>
                    </div> -->
                    <div class="col-md-3">
                        <label class="form-label text-muted">Username:</label>
                        <input type="text" class="form-control" id="username" placeholder="user name" name="username" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label text-muted">Password:</label>
                        <input type="password" class="form-control" id="password" placeholder="password" name="password" required>
                    </div>
                    
                </div>

                <div class="form-group row">
                    <!-- <div class="col-md-3">
                        <label class="form-label text-muted">Password:</label>
                    </div> -->
                    <div class="col-md-9">
                        <label class="form-label text-muted">Password:</label>
                        <input type="password" class="form-control" id="password" placeholder="password" name="password" required><br>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class="form-label text-muted">Email Address:</label>
                    </div>
                    <div class="col-md-9">
                        <input type="email" class="form-control" id="email" placeholder="email address" name="email" required><br>
                    </div>                
                </div>

                <div>
                    <button type="submit" class="btn form-control btn-primary" name="submit" value="Register">Submit</button><br>
                </div>
            </form>

            <br>
            
            <?php
                // }
            ?>
    
        </div>
    
        <!-- <footer><p><a href="logout.php">Logout</a></p></footer> -->
    </body>
</html><?php /**PATH C:\xampp\htdocs\lab-cs360\lab7-cs360\lab7\resources\views/my.blade.php ENDPATH**/ ?>