<h1>Forget Password Email</h1>
   
You can reset password from bellow link:
<a href="<?php echo e(route('reset.password.get', $token)); ?>">Reset Password</a><?php /**PATH C:\xampp\htdocs\lab-cs360\lab7-cs360\lab7\resources\views/email/forgotPassword.blade.php ENDPATH**/ ?>