

<?php echo $__env->yieldContent('navbar'); ?>
        <div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
            <div class="nano">
                <div class="nano-content">
                    <ul>
                        <div class="logo">
                                <!-- <img src="images/logo.png" alt="" /> --><span>Focus</span></a></div>
                        <li class="label">Main</li>
                        
                        <li><a><i class="ti-close"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- /# sidebar -->

        <div class="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="float-left">
                            <div class="hamburger sidebar-toggle">
                                <span class="line"></span>
                                <span class="line"></span>
                                <span class="line"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



<?php echo $__env->yieldContent('footer'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="footer">
            <p>2022 © 513 Studios.</p>
        </div>
    </div>
</div>
                <?php /**PATH C:\xampp\htdocs\lab-cs360\lab7-cs360\lab7\resources\views/navbar_template.blade.php ENDPATH**/ ?>