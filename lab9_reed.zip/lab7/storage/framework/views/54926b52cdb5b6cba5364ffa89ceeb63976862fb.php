<!DOCTYPE HTML>
<html>
    <head>
        <title>513 Studios - <?php echo $__env->yieldContent('title'); ?></title>
        <?php echo $__env->make('layouts.stylesheet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('styles'); ?>
    </head>
    <body>
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content-wrap">
            <div class="main">
                <div class="container-fluid">
                        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <section id="main content">
                        <?php echo $__env->yieldContent('content'); ?>
                        </section>

                    

                    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\lab-cs360\lab7-cs360\lab7\resources\views/layout.blade.php ENDPATH**/ ?>