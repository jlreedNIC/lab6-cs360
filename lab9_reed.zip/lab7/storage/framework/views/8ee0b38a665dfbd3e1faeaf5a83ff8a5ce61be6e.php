Testing
<br>



<?php $__env->startSection('body_section'); ?>
    Signin
<?php $__env->stopSection(); ?>
<?php echo $__env->make('login-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lab-cs360\lab7-cs360\lab7\resources\views/welcome.blade.php ENDPATH**/ ?>