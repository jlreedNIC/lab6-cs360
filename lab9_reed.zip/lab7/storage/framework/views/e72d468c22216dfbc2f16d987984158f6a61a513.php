<div class="container-fluid" style="background-color:white">
    <div class="row">
        <div class="col-lg-12">
            <div class="float-right">
                
                <div class="dropdown dib">
                    <div class="header-icon" data-toggle="dropdown">
                        <a href="<?php echo e(route('logout')); ?>">
                            <i class="ti-power-off"></i>
                            <span>Logout</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\lab-cs360\lab7-cs360\lab7\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>