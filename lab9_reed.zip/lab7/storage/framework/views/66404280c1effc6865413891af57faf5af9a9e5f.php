<div class="row">
    <div class="col-lg-12">
        <div class="footer">
            <p>2022 © 513 Studios.</p>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\lab-cs360\lab7-cs360\lab7\resources\views/layouts/footer.blade.php ENDPATH**/ ?>