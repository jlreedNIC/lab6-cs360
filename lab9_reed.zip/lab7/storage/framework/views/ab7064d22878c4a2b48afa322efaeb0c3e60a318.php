<!DOCTYPE HTML>
<html>
    <head>
        <title>Template</title>
    </head>
    
    <body>
        Neat!

        <?php echo $__env->yieldContent('body_section'); ?>
            Template content
    </body>
</html><?php /**PATH C:\xampp\htdocs\lab-cs360\lab7-cs360\lab7\resources\views/base_template.blade.php ENDPATH**/ ?>