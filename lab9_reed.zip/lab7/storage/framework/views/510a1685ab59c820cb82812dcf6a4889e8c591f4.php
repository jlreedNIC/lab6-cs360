
<title>513 Studios Login (lab9)</title>


<?php $__env->startSection('body_content'); ?>
<body class="bg-primary">
    <div class="unix-login">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="index.html"><span>513 Studios</span></a>
                        </div>

                        <div class="card-body">
                            <?php if(session('success')): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(session('message')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('message')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="login-form">
                            <h4>Developer Login</h4>
                            <form action="<?php echo e(route('login.post')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Username</label>
                                    <input type="text" class="form-control" placeholder="Username" name="username" id="username">
                                    <?php if($errors->has('username')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" class="form-control" placeholder="Password" name="password" id="password">
                                    <?php if($errors->has('password')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="checkbox">
                                    <label class="pull-right">
                                    <a href="<?php echo e(route('forget.password.get')); ?>">Forgotten Password?</a>
									</label>

                                </div>

                                <button type="submit" class="btn btn-primary btn-flat m-b-30 m-t-30">Sign in</button>
                                
                                <div class="register-link m-t-15 text-center">
                                    <p>Don't have account ? <a href="<?php echo e(route('register')); ?>"> Sign Up Here</a></p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sample_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lab-cs360\lab7-cs360\lab7\resources\views/auth/real-login.blade.php ENDPATH**/ ?>